Thank you for downloading the Boolean Logic in Excel eBook bundle!

Folders:
/Digital_Edition/   → DOCX (editable), PDF (optimized), EPUB (eReader)
/KDP_Print/         → Interior_6x9.pdf (print-ready placeholder), Cover_Print.pdf
/Marketing_Assets/  → 3D mockups, transparent cover, logo, Canva templates
/Etsy_Thumbnails/   → 2000x2000 mockups + cover

Created by Digital Products Artisan | https://www.digitalproductsartisan.com