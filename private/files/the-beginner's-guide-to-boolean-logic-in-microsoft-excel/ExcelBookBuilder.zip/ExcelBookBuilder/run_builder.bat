@echo off
cd /d "%~dp0"
where python >nul 2>&1
if %errorlevel% neq 0 (
  echo Python not found. Install Python from https://www.python.org/downloads/
  pause
  exit /b
)
python -m pip install --upgrade pip
python -m pip install python-docx reportlab fpdf ebooklib openpyxl pillow
python build_boolean_book_bundle.py
echo.
echo Finished! Press any key to open the output folder...
pause
start "" "%cd%"
