#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Builds two ZIPs locally:
  - Boolean_Logic_Excel_Guide_Final_v1.0.zip  (full bundle)
  - Boolean_Logic_Excel_Guide_Lite_v1.0.zip  (book-only)
  
Install once:
  pip install python-docx reportlab fpdf ebooklib openpyxl pillow

Run:
  python build_boolean_book_bundle.py
"""

import os, zipfile, datetime
from pathlib import Path
from io import BytesIO
from textwrap import dedent, fill

# --- Config (edit if you like) ---
BRAND = "Digital Products Artisan"
AUTHOR = "Digital Products Artisan"
WEBSITE = "https://www.digitalproductsartisan.com"
ETSY_LINK = "https://www.etsy.com"
KDP_LINK = "https://kdp.amazon.com"
TITLE = "The Beginner's Guide to Boolean Logic in Microsoft Excel"
VERSION = "v1.0"
OUTPUT_ROOT = Path.cwd() / f"Boolean_Logic_Excel_Guide_{VERSION}_BUILD"
ZIP_FINAL = Path.cwd() / f"Boolean_Logic_Excel_Guide_Final_{VERSION}.zip"
ZIP_LITE  = Path.cwd() / f"Boolean_Logic_Excel_Guide_Lite_{VERSION}.zip"

# --- Imports that require pip packages (only used when you run locally) ---
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.shared import OxmlElement, qn

from reportlab.lib.pagesizes import A4, letter
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

from fpdf import FPDF
from ebooklib import epub
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from PIL import Image, ImageDraw, ImageFont

# ------------- Utilities -------------
def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)

def write_text(path: Path, text: str):
    path.write_text(text, encoding="utf-8")

def add_page_number_footer(doc: Document):
    """Add footer 'Brand | Page #' to document."""
    section = doc.sections[0]
    footer = section.footer
    paragraph = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    paragraph.text = f"{BRAND} | Page "
    # Page number field
    fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.text = "PAGE"
    fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
    r = paragraph.add_run()
    r._r.append(fldChar1); r._r.append(instrText); r._r.append(fldChar2)

def heading(doc, text, level=1, align_center=False):
    p = doc.add_paragraph(text, style=f"Heading {level}")
    if align_center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p

def para(doc, text, bold=False, italic=False, size=12):
    run = doc.add_paragraph().add_run(text)
    run.bold = bold; run.italic = italic; run.font.size = Pt(size)

def code_block(doc, code: str):
    p = doc.add_paragraph()
    r = p.add_run(code)
    r.font.name = "Consolas"
    r.font.size = Pt(10)
    p.paragraph_format.left_indent = Inches(0.25)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    shading_elm = OxmlElement('w:shd')
    shading_elm.set(qn('w:fill'), "DDDDDD")
    p._p.get_or_add_pPr().append(shading_elm)

def callout_box(doc, title: str, items: list, fill_hex="DDEBF7"):
    # Simple callout using table shading
    table = doc.add_table(rows=1+len(items), cols=1)
    table.autofit = True
    a = table.rows[0].cells[0].paragraphs[0]
    a.add_run(title).bold = True
    for i, line in enumerate(items, start=1):
        table.rows[i].cells[0].paragraphs[0].add_run("• " + line)
    tbl = table._tbl
    tblPr = tbl.tblPr
    shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill_hex)
    for row in table.rows:
        tcPr = row.cells[0]._tc.get_or_add_tcPr()
        tcPr.append(shd)

# ------------- Content Builders -------------
def build_docx_book(dst: Path):
    doc = Document()
    style = doc.styles['Normal']; style.font.name = "Arial"; style.font.size = Pt(12)

    # Cover Page
    p = heading(doc, TITLE, level=1, align_center=True)
    para(doc, f"By {AUTHOR}", italic=True, size=12)
    doc.add_page_break()

    # Dedication
    heading(doc, "Dedication", level=1)
    para(doc, "For learners everywhere who believe that knowledge is power — may this guide help you unlock Excel’s hidden logic.", italic=True)
    doc.add_page_break()

    # Preface
    heading(doc, "Preface", level=1)
    para(doc, "Welcome! This book turns Excel from a grid of cells into a smart decision engine using Boolean logic.", size=12)
    callout_box(doc, "Who this is for", ["Students & self-learners", "Entrepreneurs & small businesses", "Professionals upgrading Excel skills"], "E2F0D9")
    doc.add_page_break()

    # Tips
    heading(doc, "Tips for Using This Book", level=1)
    callout_box(doc, "Pro Tips", [
        "Open Excel and follow along with the examples.",
        "Try exercises before peeking at the solutions.",
        "Keep the Cheat Sheet handy while practicing."
    ], "FFF2CC")
    doc.add_page_break()

    # Foreword
    heading(doc, "Foreword", level=1)
    para(doc, "Logic powers modern computing. In Excel, Boolean logic enables smarter filters, cleaner reports, and faster decisions.", size=12)
    doc.add_page_break()

    # Table of Contents (Word can auto-generate)
    heading(doc, "Table of Contents", level=1)
    para(doc, "In Microsoft Word: References → Table of Contents → Automatic.", italic=True)
    doc.add_page_break()

    # List of Figures & Tables
    heading(doc, "List of Figures & Tables", level=1)
    para(doc, "[Placeholder] Insert figure/table captions to populate this list automatically.", size=11)
    doc.add_page_break()

    # Chapters (abbreviated but substantial)
    chapters = [
        ("Chapter 1: Introduction to Boolean Logic",
         ["What Boolean logic is and why it matters in Excel.",
          "TRUE/FALSE values, equality tests, and practical uses."]),
        ("Chapter 2: Logical Operators",
         ["=, >, <, >=, <=, <> and examples with data.",
          "Truth tables and common comparison pitfalls."]),
        ("Chapter 3: Core Functions: IF, AND, OR, NOT, XOR",
         ["Function syntax and practical patterns.",
          "Common mistake: text 'TRUE' vs Boolean TRUE."]),
        ("Chapter 4: Advanced Logic: IFS, SWITCH, CHOOSE, LET, LAMBDA",
         ["Cleaner alternatives to nested IFs.",
          "Designing reusable logic with LET/LAMBDA."]),
        ("Chapter 5: Data Analysis with Boolean Logic",
         ["COUNTIF/COUNTIFS, SUMIF/SUMIFS, AVERAGEIF(S).",
          "SUMPRODUCT for advanced conditional math."]),
        ("Chapter 6: Dynamic Arrays & Filtering",
         ["FILTER, SORT, UNIQUE with logical criteria.",
          "Building interactive mini-dashboards."]),
        ("Chapter 7: Conditional Formatting & Validation",
         ["Formula-based formatting rules.",
          "Data validation with logical expressions."]),
        ("Chapter 8: Business Case Studies",
         ["HR eligibility checklist.", "Finance approvals.", "Inventory alerts.", "Marketing segmentation."]),
        ("Chapter 9: Troubleshooting & Best Practices",
         ["Avoid over-nesting.", "Consistent TRUE/FALSE handling.", "Document assumptions."]),
        ("Chapter 10: Exercises & Solutions",
         ["20+ graded exercises with step-by-step answers."]),
        ("Cheat Sheet: Boolean Quick Reference", ["Operators, functions, and patterns at-a-glance."]),
        ("Conclusion & Next Steps", ["Where to go next: Power Query, Power BI, VBA."]),
    ]

    for title, bullets in chapters:
        heading(doc, title, level=1)
        para(doc, f"*Opening quote goes here in italics*", italic=True)
        for b in bullets:
            para(doc, "• " + b)
        # Sample formulas as code blocks
        code_block(doc, '=IF(AND(A2>=75,B2="Yes"),"Eligible","Not Eligible")')
        code_block(doc, '=SUMPRODUCT((A2:A100>0)*(B2:B100="Paid")*C2:C100)')
        callout_box(doc, "💡 Pro Tip", ["Prefer COUNTIFS/SUMIFS over nested IFs for clarity."], "E2F0D9")
        callout_box(doc, "🔑 Key Takeaways", ["Keep logic readable.", "Test with sample data.", "Use helper columns."], "DDEBF7")
        doc.add_page_break()

    # About the Author, References, Bonus Resources, Thank You
    heading(doc, "About the Author", level=1); para(doc, f"{BRAND} creates practical, high-quality digital resources.", size=12); doc.add_page_break()
    heading(doc, "References / Further Reading", level=1); para(doc, "Microsoft Learn: Excel functions; Community tutorials; Books.", size=12); doc.add_page_break()
    heading(doc, "Bonus Resources", level=1); para(doc, "Links to templates, videos, and checklists.", size=12); doc.add_page_break()
    heading(doc, "Thank You", level=1); para(doc, "If you enjoyed this guide, please leave a review and share it.", size=12)

    add_page_number_footer(doc)
    dst.parent.mkdir(parents=True, exist_ok=True)
    doc.save(dst)

def build_pdf_checklist(dst: Path, title="Bonus Checklist"):
    doc = SimpleDocTemplate(str(dst), pagesize=A4, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    h = ParagraphStyle("H", parent=styles["Heading1"], textColor=colors.HexColor("#0A2A43"))
    p = ParagraphStyle("P", parent=styles["Normal"], fontName="Helvetica", fontSize=11, leading=14)
    items = [
        "Finalize DOCX, PDF, EPUB files",
        "Upload PDF to Etsy (+ thumbnails)",
        "Upload EPUB + Cover to KDP (Kindle)",
        "Upload 6x9 PDF + Print Cover to KDP (paperback)",
        "Post promos using captions + hashtags",
    ]
    story = [Paragraph(f"{title} — {BRAND}", h), Spacer(1, 12)]
    for it in items:
        story.append(Paragraph("• " + it, p)); story.append(Spacer(1,6))
    doc.build(story)

def build_pdf_quickstart(dst: Path):
    doc = SimpleDocTemplate(str(dst), pagesize=A4, leftMargin=54, rightMargin=54, topMargin=54, bottomMargin=54)
    styles = getSampleStyleSheet()
    h = ParagraphStyle("H", parent=styles["Heading1"], textColor=colors.HexColor("#0A2A43"))
    p = ParagraphStyle("P", parent=styles["Normal"], fontName="Helvetica", fontSize=11, leading=14)
    story = [
        Paragraph("Your Excel Logic Starter Kit: Quick Start Guide", h), Spacer(1,12),
        Paragraph("What’s inside: eBook (DOCX, PDF, EPUB), KDP print edition, marketing assets, strategy guides.", p), Spacer(1,8),
        Paragraph("First 3 steps:", h), Spacer(1,6),
        Paragraph("1) Upload PDF to Etsy with thumbnails.", p),
        Paragraph("2) Upload EPUB + Cover (Kindle) and 6x9 PDF + Cover (paperback) to KDP.", p),
        Paragraph("3) Post your launch using the provided captions & hashtags.", p),
    ]
    doc.build(story)

def build_epub(dst: Path, title: str, author: str, body: str):
    book = epub.EpubBook()
    book.set_identifier("boolean-logic-excel-kit")
    book.set_title(title)
    book.set_language('en')
    book.add_author(author)

    c1 = epub.EpubHtml(title=title, file_name='intro.xhtml', lang='en')
    c1.content = f"<h1>{title}</h1><p>{body}</p>"
    book.add_item(c1)
    book.toc = (epub.Link('intro.xhtml', 'Start', 'intro'),)
    book.add_item(epub.EpubNcx()); book.add_item(epub.EpubNav())
    book.spine = ['nav', c1]
    epub.write_epub(str(dst), book, {})

def build_xlsx_metrics(dst: Path):
    wb = Workbook()
    ws = wb.active; ws.title = "Etsy Sales"
    ws.append(["Date","Product","Units","Revenue","Fees","Net Profit"])
    ws.column_dimensions['A'].width = 12
    ws.freeze_panes = "A2"
    ws2 = wb.create_sheet("KDP Sales"); ws2.append(["Date","Kindle Units","Paperback Units","Royalties"])
    ws3 = wb.create_sheet("Website Sales"); ws3.append(["Date","Orders","Revenue","Source"])
    ws4 = wb.create_sheet("Social Media"); ws4.append(["Platform","Posts","Views","Likes","Comments","Shares","Clicks","Engagement%"])
    wb.save(dst)

def build_xlsx_competitor(dst: Path):
    wb = Workbook()
    ws = wb.active; ws.title = "Etsy"
    ws.append(["Shop","Product","Price","Sales","Tags","Design Notes","Rating"])
    ws2 = wb.create_sheet("KDP"); ws2.append(["Title","Author","Kindle Price","Paperback Price","Reviews","Avg Rating","Categories"])
    ws3 = wb.create_sheet("Keywords"); ws3.append(["Keyword","Platform","Volume","Competition","Intent"])
    wb.save(dst)

def create_mock_image(dst: Path, text="Excel Book", size=(2000,2000), bg="#0A2A43"):
    img = Image.new("RGB", size, color=bg)
    d = ImageDraw.Draw(img)
    try:
        fnt = ImageFont.load_default()
    except:
        fnt = None
    tw, th = d.textsize(text, font=fnt)
    d.text(((size[0]-tw)//2, (size[1]-th)//2), text, fill="white", font=fnt)
    img.save(dst)

def build_kdp_interior_pdf(dst: Path):
    # 6x9 inches
    W, H = 6*inch, 9*inch
    c = canvas.Canvas(str(dst), pagesize=(W,H))
    c.setFont("Helvetica-Bold", 14)
    c.drawString(1*inch, H-1*inch, TITLE)
    c.setFont("Helvetica", 10)
    txt = ("Print interior (B&W). Replace with your finalized manuscript export for print. "
           "Margins and size are set to 6x9in.")
    c.drawString(1*inch, H-1.3*inch, txt)
    c.showPage(); c.save()

def build_print_cover_pdf(dst: Path):
    # Simple flat cover (front only) placeholder as PDF
    c = canvas.Canvas(str(dst), pagesize=letter)
    c.setFillColor(colors.HexColor("#0A2A43")); c.rect(0,0,letter[0],letter[1], fill=True, stroke=False)
    c.setFillColor(colors.white); c.setFont("Helvetica-Bold", 24)
    c.drawString(72, letter[1]-100, TITLE)
    c.setFont("Helvetica", 14); c.drawString(72, letter[1]-130, f"By {AUTHOR}")
    c.save()

def build_all():
    # Folder structure
    root = OUTPUT_ROOT
    d_digital = root / "Digital_Edition"
    d_kdp = root / "KDP_Print"
    d_marketing = root / "Marketing_Assets"
    d_thumbs = root / "Etsy_Thumbnails"

    for d in (d_digital,d_kdp,d_marketing,d_thumbs):
        ensure_dir(d)

    # --- Book files ---
    # DOCX
    docx_path = d_digital / "Boolean_Logic_Excel_Guide.docx"
    build_docx_book(docx_path)
    # EPUB
    epub_path = d_digital / "Boolean_Logic_Excel_Guide.epub"
    build_epub(epub_path, TITLE, AUTHOR, "Start reading your guide. (Full content is in the DOCX/PDF manuscript.)")
    # Optimized PDF (simple typeset from reportlab summary)
    pdf_path = d_digital / "Boolean_Logic_Excel_Guide.pdf"
    build_pdf_quickstart(pdf_path)  # lightweight; you can export full PDF from Word for final
    # README & Docs
    write_text(root / "README.txt", dedent(f"""
        Thank you for downloading the Boolean Logic in Excel eBook bundle!

        Folders:
        /Digital_Edition/   → DOCX (editable), PDF (optimized), EPUB (eReader)
        /KDP_Print/         → Interior_6x9.pdf (print-ready placeholder), Cover_Print.pdf
        /Marketing_Assets/  → 3D mockups, transparent cover, logo, Canva templates
        /Etsy_Thumbnails/   → 2000x2000 mockups + cover

        Created by {BRAND} | {WEBSITE}
    """).strip())

    write_text(root / "Product_Description.txt", 
        "Short & long SEO descriptions + keywords for Etsy/KDP.\n\nKeywords: Excel, Boolean logic, IF, AND, OR, data analysis, beginners, eBook.")
    write_text(root / "Pricing_Strategy.txt", "Suggested pricing for Etsy/KDP + promotions calendar.")
    write_text(root / "Social_Media_Captions.txt", "Instagram/TikTok/Pinterest captions with CTAs + hashtags.")
    write_text(root / "Hashtag_List.txt", "#Excel #ExcelTips #LearnExcel #DigitalProducts #PassiveIncome ...")
    write_text(root / "Launch_Plan.txt", "Step-by-step checklist from file prep → launch day → post-launch.")
    write_text(root / "Future_Ideas.txt", "Templates, cheat sheets, advanced guides, bundles, video tutorials.")
    write_text(root / "Mockup_Templates.txt", "Links/suggestions for Canva/PSD mockups to reuse.")
    write_text(root / "Content_Calendar.txt", "30-day posting plan across IG/TikTok/Pinterest/Twitter.")
    write_text(root / "Canva_Brand_Kit.txt", "Colors: Navy #0A2A43, Green #1FA67A, Gold #C9A227. Fonts: Headings/Body: Arial/Segoe UI.")
    write_text(root / "Tips_For_Scaling.txt", "How to grow into a product ecosystem + email list + bundles.")
    # Branded PDFs
    build_pdf_checklist(root / "Bonus_Checklist.pdf", "Launch Checklist")
    build_pdf_quickstart(root / "Quick_Start_Guide.pdf")
    # Promo copy
    write_text(root / "Bundle_Promo_Captions.txt", "Short/long promo lines for ads/socials emphasizing full kit value.")
    write_text(root / "Pinterest_Pin_Templates.txt", "Canva links + headline ideas for 5 pin designs.")
    write_text(root / "YouTube_Script_Ideas.txt", "Tutorial + product promo script outlines.")
    write_text(root / "Lead_Magnet_Ideas.txt", "Cheat sheet, mini template, short guide, free video.")
    write_text(root / "Email_Sequence.txt", "5-email nurture sequence: welcome, quick win, story, social proof, final CTA.")
    write_text(root / "Pinterest_Board_Ideas.txt", "Board names, pin categories, posting cadence.")
    write_text(root / "Website_LandingPage_Copy.txt", "Hero, value bullets, CTA, social proof, guarantee, final CTA.")
    write_text(root / "Facebook_Ads_Copy.txt", "Short + long ad copy variations + targeting ideas.")
    write_text(root / "TikTok_Reels_Ideas.txt", "30 short-form content ideas + CTAs.")
    write_text(root / "Cross_Promotion_Strategy.txt", "Loop Etsy ↔ KDP ↔ Website ↔ Socials; build email list.")
    write_text(root / "Review_Request_Captions.txt", "Polite asks for reviews (Etsy, KDP, email, socials).")
    write_text(root / "Discount_Coupon_Strategy.txt", "When/how to run coupons; urgency; bundles; email-only codes.")
    write_text(root / "Bundle_Expansion_Strategy.txt", "Bundle the eBook with templates, cheat sheets, and videos.")
    write_text(root / "Keyword_Research_Guide.txt", "Free + paid tools; scoring; choosing top tags; rotation plan.")
    write_text(root / "Blog_Post_Ideas.txt", "20+ SEO titles to drive traffic to your book.")
    write_text(root / "Changelog.txt", f"Version {VERSION} – Initial Release\n✔ eBook files + KDP\n✔ Marketing suite\n✔ Launch & growth toolkit\n✔ Branded PDFs\n✔ Analytics & research tools")

    # Business tools
    from openpyxl import Workbook
    metrics_xlsx = root / "Metrics_Tracking_Template.xlsx"
    build_xlsx_metrics(metrics_xlsx)
    comp_xlsx = root / "Competitor_Research_Template.xlsx"
    build_xlsx_competitor(comp_xlsx)

    # Customer tools
    feedback_docx = root / "Customer_Feedback_Form.docx"
    doc = Document(); heading(doc, "Customer Feedback Form", 1)
    para(doc, f"Thank you for purchasing {TITLE}! Your feedback helps us improve.", size=12)
    doc.save(feedback_docx)

    # KDP files
    build_kdp_interior_pdf(d_kdp / "Interior_6x9.pdf")
    build_print_cover_pdf(d_kdp / "Cover_Print.pdf")

    # Marketing Assets: mock images + logo + Canva template placeholders
    create_mock_image(d_marketing / "Mockup_Standing.png", "Excel Book Mockup", (2400,1600), "#0A2A43")
    create_mock_image(d_marketing / "Mockup_Stack.png", "Stack Mockup", (2400,1600), "#1FA67A")
    create_mock_image(d_marketing / "Mockup_Desk.png", "Desk Scene", (2400,1600), "#C9A227")
    create_mock_image(d_marketing / "Cover_Transparent.png", "Book Cover", (1600,2400), "#0A2A43")
    create_mock_image(d_marketing / "Brand_Logo.png", BRAND, (1200,400), "#0A2A43")
    write_text(d_marketing / "Shop_Banner_Canva_Template.txt", "Canva link placeholder for Etsy shop banner (3360x840)")
    write_text(d_marketing / "Thank_You_Card_Canva_Template.txt", "Canva link placeholder for A6 thank you card template")

    # Etsy Thumbnails 2000x2000
    create_mock_image(d_thumbs / "Thumb_Standing_2000.png", "Excel Book", (2000,2000), "#0A2A43")
    create_mock_image(d_thumbs / "Thumb_Stack_2000.png", "Stack", (2000,2000), "#1FA67A")
    create_mock_image(d_thumbs / "Thumb_Desk_2000.png", "Desk", (2000,2000), "#C9A227")
    create_mock_image(d_thumbs / "Thumb_Cover_2000.png", "Cover", (2000,2000), "#0A2A43")

    # --- LITE readme (for the Lite ZIP) ---
    write_text(root / "Lite_README.txt", dedent(f"""
        Thank you for downloading the Beginner’s Guide to Boolean Logic in Excel (Lite Edition).

        This ZIP includes:
        ✔ DOCX (editable source file): /Digital_Edition/Boolean_Logic_Excel_Guide.docx
        ✔ PDF (optimized): /Digital_Edition/Boolean_Logic_Excel_Guide.pdf
        ✔ EPUB (eReader): /Digital_Edition/Boolean_Logic_Excel_Guide.epub

        ⚡ Want more? Upgrade to the FULL BUSINESS KIT:
        ✔ KDP print-ready files (interior + cover)
        ✔ 3D mockups, Etsy thumbnails, Canva templates
        ✔ SEO product descriptions + pricing strategies
        ✔ Social captions, hashtags, ads copy
        ✔ Launch plan, growth tips, scaling strategies
        ✔ Branded Quick Start Guide + Checklist
        ✔ Analytics trackers + competitor research tools
        ✔ And more…

        Visit: {WEBSITE}  |  Etsy: {ETSY_LINK}
    """).strip())

    # ---- ZIP: Final (full) ----
    if ZIP_FINAL.exists(): ZIP_FINAL.unlink()
    with zipfile.ZipFile(ZIP_FINAL, "w", zipfile.ZIP_DEFLATED) as z:
        for p in OUTPUT_ROOT.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(OUTPUT_ROOT))

    # ---- ZIP: Lite (book-only) ----
    if ZIP_LITE.exists(): ZIP_LITE.unlink()
    with zipfile.ZipFile(ZIP_LITE, "w", zipfile.ZIP_DEFLATED) as z:
        # Only include /Digital_Edition + Lite_README
        for p in (OUTPUT_ROOT / "Digital_Edition").rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(OUTPUT_ROOT))
        z.write(OUTPUT_ROOT / "Lite_README.txt", Path("Lite_README.txt"))

    print(f"Done.\nFull ZIP:   {ZIP_FINAL}\nLite ZIP:   {ZIP_LITE}")

if __name__ == "__main__":
    ensure_dir(OUTPUT_ROOT)
    build_all()
